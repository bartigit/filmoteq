package com.example.filmoteq.model

enum class Status { Obejrzany, Nieobejrzany }