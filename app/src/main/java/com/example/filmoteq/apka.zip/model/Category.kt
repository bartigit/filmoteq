package com.example.filmoteq.model

enum class Category { Akcji, Przygodowy, Obyczajowy, Komedia }
